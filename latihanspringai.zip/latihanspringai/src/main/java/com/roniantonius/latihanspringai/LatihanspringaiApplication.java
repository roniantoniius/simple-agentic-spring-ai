package com.roniantonius.latihanspringai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LatihanspringaiApplication {

	public static void main(String[] args) {
		SpringApplication.run(LatihanspringaiApplication.class, args);
	}

}
