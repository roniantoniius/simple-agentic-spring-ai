package com.roniantonius.latihanspringai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LatihanspringaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
